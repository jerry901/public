
int dbupdate(int argc, char *argv[]);
