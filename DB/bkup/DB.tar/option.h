#define ERROR -1
#define HELP 0
#define OPEN 1
#define CREATE 2
#define DELETE 3
#define UPDATE 4 
#define LIST 5 
#define ADD 6
#define QUERY 7 

int getOption(char* ptrOpt);


