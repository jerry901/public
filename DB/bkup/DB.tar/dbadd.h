int dbadd(int argc, char* argv[]);
