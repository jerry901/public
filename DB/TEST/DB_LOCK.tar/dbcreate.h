
int dbcreate(int argc, char *argv[]);
