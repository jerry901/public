#define MAX 24
#define START_ID 0000001

struct student {
   char name[MAX];
   int id;
   int score;
};

